﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MyApp.Application.Repositories;
using MyApp.Domain.Entities;

namespace MyApp.Infraestructure.Repositories
{
    internal class WeatherForecastRepository : IWeatherForecastRepository

    {
        public IEnumerable<WeatherForecast> GetAll() 
        {
            var summaries = new[]
            {
                "Freezing", "Bracing", "Chilly", "Cool","Warm", "Balmy","Hot","Sweltering","Scorching"
            };

            var forecast = Enumerable.Range(1,5).Select(index=>
                new WeatherForecast
                (
                    DateTime.Now.AddDays(index),
                    Random.Shared.Next(-20,55),
                    summaries[Random.Shared.Next(summaries.Length)]
                )).ToArray();

            return forecast;
        }
            
    }
}
