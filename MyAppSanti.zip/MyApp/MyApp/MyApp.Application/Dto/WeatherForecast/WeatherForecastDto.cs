﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MyApp.Application.Dto.WeatherForecast
{
    public record WeatherForecastDto(DateTime Date, int TemperatureC, int TemperatureF, string? Summary);
}


