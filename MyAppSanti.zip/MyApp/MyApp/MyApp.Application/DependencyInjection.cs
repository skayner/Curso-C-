﻿using MediatR;
using Microsoft.Extensions.DependencyInjection;
using MyApp.Application.Data;
using MyApp.Application.Dto.Result;
using MyApp.Application.Services;
using MyApp.Application.Services.Internals;
using MyApp.Domain.Entities;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading.Tasks;

namespace MyApp.Application
{
    public static class DependencyInjection
    {
        public static IServiceCollection AddMyAppApplication(this IServiceCollection services)
        {
            services.AddScoped<IWeatherForecastService, WeatherForecastService>();

            services.AddMediatR(typeof(Result));

            return services;
        }
    }
}
