﻿using MediatR;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore.Metadata;
using MyApp.Api.Extensions.ResultExtensions;
using MyApp.Application.UseCases.Products.CreateProduct;
using MyApp.Application.UseCases.Products.DeleteProduct;
using MyApp.Application.UseCases.Products.GetAllProducts;
using MyApp.Application.UseCases.Products.GetProductById;
using MyApp.Application.UseCases.Products.PutProduct;

namespace MyApp.Api.Routes
{
    public static class ProductsRoutes
    {
        public static  IEndpointRouteBuilder MapProducts(this IEndpointRouteBuilder builder)
        {
            const string PATH = "/Products";

            //builder.MapGet(PATH, async (IMediator mediator)
            //  => await mediator.Send(new GetAllProductsRequest()).ToHttpResult());

            //builder.MapPost(PATH, async (IMediator mediator, [FromBody] CreateProductRequest request)
            //  => await mediator.Send(request).ToHttpResult());

            //builder.MapPut(PATH , async (IMediator mediator, [FromBody] UpdateProductRequest request)
            //  => await mediator.Send(request).ToHttpResult());

            //builder.MapDelete(PATH + "/{id}", async (int id, IMediator mediator)
            //   => await mediator.Send(new DeleteProductRequest(id)).ToHttpResult());

            //builder.MapGet(PATH + "/{id}", async (int id, IMediator mediator)
            //    => await mediator.Send(new GetProductByIdRequest(id)).ToHttpResult());

            builder.MapGet("/Products", async ([FromServices] IMediator mediator)
                => Results.Ok(await mediator.Send(new GetAllProductsRequest())))
                .WithName("GetProducts")
                .Produces<IEnumerable<GetAllProductsResponse>>(StatusCodes.Status200OK, "application/json");

            builder.MapPost("/Products", async ([FromServices] IMediator mediator, [FromBody] CreateProductRequest request)
                => Results.Ok(await mediator.Send(request)))
                .WithName("CreateProducts")
                .Produces<CreateProductResponse>(StatusCodes.Status200OK, "application/json");

            builder.MapPut("/Products", async ([FromServices] IMediator mediator, [FromBody] UpdateProductRequest request)
                => Results.Ok(await mediator.Send(request)))
                .WithName("UpdateProducts")
                .Produces<UpdateProductResponse>(StatusCodes.Status200OK, "application/json");

            builder.MapDelete("/Products/{id}", async ([FromServices] IMediator mediator, [FromRoute] int id)
                => Results.Ok(await mediator.Send(new DeleteProductRequest(id))))
                .WithName("DeleteProducts");

            builder.MapGet("/Products/{id}", async ([FromServices] IMediator mediator, [FromRoute] int id)
                => Results.Ok(await mediator.Send(new GetProductByIdRequest(id))))
                .WithName("GetProductById")
                .Produces<GetProductByIdResponse>(StatusCodes.Status200OK, "application/json");


            return builder;
        }
    }
}
